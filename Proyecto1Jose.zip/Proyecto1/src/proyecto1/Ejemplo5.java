/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import java.io.PrintStream;

/**
 *
 * @author Salas
 */
public class Ejemplo5 {
    public static void main(String[] args) {
        String nombre = "José";
        String apellido = "Calva";
        int edad = 18; 
        double valor_celular = 200; 
        
        System.out.printf("%s %s\n\tEdad:%d\n\t$ celular:%.2f\n",
        nombre, apellido.toUpperCase(), edad, valor_celular);
    }
}
